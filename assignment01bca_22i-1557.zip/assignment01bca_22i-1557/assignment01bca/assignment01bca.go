package assignment01bca

import (
	"crypto/sha256"
	"fmt"
	"strconv"
	"strings"
	"time"
)

type Block struct {
	Transaction  string
	Nonce        int
	PreviousHash string
	Hash         string
	Index        int
	Timestamp    string
}

var Blockchain []*Block

func CalculateHash(stringToHash string) string {
	hash := sha256.Sum256([]byte(stringToHash))
	return fmt.Sprintf("%x", hash)
}

func createHash(b *Block) string {
	data := b.Transaction +
		strconv.Itoa(b.Nonce) +
		b.PreviousHash +
		strconv.Itoa(b.Index) +
		b.Timestamp
	return CalculateHash(data)
}

func NewBlock(transaction string, nonce int, previousHash string) *Block {
	b := &Block{
		Transaction:  transaction,
		Nonce:        nonce,
		PreviousHash: previousHash,
		Index:        len(Blockchain),
		Timestamp:    time.Now().String(),
	}
	b.Hash = createHash(b)
	Blockchain = append(Blockchain, b)
	return b
}

func ListBlocks() {
	fmt.Println(strings.Repeat("=", 60))
	fmt.Println("           COMPLETE BLOCKCHAIN")
	fmt.Println(strings.Repeat("=", 60))

	for _, b := range Blockchain {
		fmt.Println(strings.Repeat("-", 60))
		fmt.Printf("Block Index   : %d\n", b.Index)
		fmt.Printf("Transaction   : %s\n", b.Transaction)
		fmt.Printf("Nonce         : %d\n", b.Nonce)
		fmt.Printf("Previous Hash : %s\n", b.PreviousHash)
		fmt.Printf("Block Hash    : %s\n", b.Hash)
		fmt.Printf("Timestamp     : %s\n", b.Timestamp)
		fmt.Println(strings.Repeat("-", 60))
	}
	fmt.Println()
}

func ChangeBlock(index int, newTransaction string) {
	if index < 0 || index >= len(Blockchain) {
		fmt.Println("Error: Block index out of range!")
		return
	}
	fmt.Printf("Tampering Block %d: changing transaction to \"%s\"\n", index, newTransaction)
	Blockchain[index].Transaction = newTransaction
}

func VerifyChain() bool {
	fmt.Println(strings.Repeat("=", 60))
	fmt.Println("           VERIFYING BLOCKCHAIN")
	fmt.Println(strings.Repeat("=", 60))

	isValid := true

	for i := 0; i < len(Blockchain); i++ {
		currentBlock := Blockchain[i]

		recalculatedHash := createHash(currentBlock)
		if currentBlock.Hash != recalculatedHash {
			fmt.Printf("FAIL: Block %d hash mismatch!\n", i)
			fmt.Printf("  Stored hash     : %s\n", currentBlock.Hash)
			fmt.Printf("  Recalculated    : %s\n", recalculatedHash)
			isValid = false
		}

		if i > 0 {
			previousBlock := Blockchain[i-1]
			if currentBlock.PreviousHash != previousBlock.Hash {
				fmt.Printf("FAIL: Block %d previous hash does not match Block %d hash!\n", i, i-1)
				isValid = false
			}
		}
	}

	if isValid {
		fmt.Println("Result: Blockchain is VALID. No tampering detected.")
	} else {
		fmt.Println("Result: Blockchain is INVALID! Tampering detected!")
	}
	fmt.Println(strings.Repeat("=", 60))
	fmt.Println()

	return isValid
}
