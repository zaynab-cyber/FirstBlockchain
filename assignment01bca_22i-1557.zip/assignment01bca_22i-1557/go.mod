module blockchain-assignment

go 1.26.1

require assignment01bca v0.0.0

replace assignment01bca => ./assignment01bca
