package main

import (
	"fmt"
	"assignment01bca"
)

func main() {

	rollNoLast3 := "557"
	rollNo := "1557"
	nonceGenesis := 1 + 5 + 5 + 7 

	genesisTransaction := "Genesis Block - " + rollNo
	assignment01bca.NewBlock(genesisTransaction, nonceGenesis, "")

	assignment01bca.NewBlock(
		"Alice to Bob 10 coins - "+rollNoLast3,
		12,
		assignment01bca.Blockchain[0].Hash,
	)

	assignment01bca.NewBlock(
		"Bob to Charlie 5 coins",
		34,
		assignment01bca.Blockchain[1].Hash,
	)

	assignment01bca.NewBlock(
		"Charlie to Dave 3 coins - "+rollNoLast3,
		56,
		assignment01bca.Blockchain[2].Hash,
	)

	fmt.Println(">>> PRINTING BLOCKCHAIN BEFORE TAMPERING <<<")
	assignment01bca.ListBlocks()

	fmt.Println(">>> VERIFICATION BEFORE TAMPERING <<<")
	assignment01bca.VerifyChain()

	fmt.Println(">>> TAMPERING WITH BLOCK 1 <<<")
	assignment01bca.ChangeBlock(1, "HACKED: Alice to Eve 1000 coins")
	fmt.Println()

	fmt.Println(">>> PRINTING BLOCKCHAIN AFTER TAMPERING <<<")
	assignment01bca.ListBlocks()

	fmt.Println(">>> VERIFICATION AFTER TAMPERING <<<")
	assignment01bca.VerifyChain()
}
